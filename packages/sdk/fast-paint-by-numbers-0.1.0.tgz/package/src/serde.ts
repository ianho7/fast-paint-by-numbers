export function snakeToCamelObject<T>(input: unknown): T {
  if (Array.isArray(input)) {
    return input.map((item) => snakeToCamelObject(item)) as T;
  }

  if (input instanceof Uint8Array || input instanceof Uint32Array || input === null || typeof input !== "object") {
    return input as T;
  }

  const output: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(input)) {
    const camelKey = key.replace(/_([a-z])/g, (_, char: string) => char.toUpperCase());
    output[camelKey] = snakeToCamelObject(value);
  }
  return output as T;
}

export function buildRustSettings(options: import("./types.js").GenerateOptions = {}) {
  return {
    random_seed: options.randomSeed ?? 0,
    kmeans_clusters: options.kmeansClusters ?? 16,
    kmeans_min_delta: options.kmeansMinDelta ?? 1,
    kmeans_color_space: options.kmeansColorSpace ?? "rgb",
    color_restrictions: options.colorRestrictions ?? [],
    color_aliases: options.colorAliases ?? {},
    narrow_pixel_cleanup_runs: options.narrowPixelCleanupRuns ?? 3,
    remove_facets_smaller_than: options.removeFacetsSmallerThan ?? 20,
    remove_facets_from_large_to_small: options.removeFacetsFromLargeToSmall ?? true,
    maximum_number_of_facets: options.maximumNumberOfFacets ?? 4294967295,
    border_smoothing_passes: options.borderSmoothingPasses ?? 2,
    resize: {
      enabled: options.resize?.enabled ?? true,
      max_width: options.resize?.maxWidth ?? 1024,
      max_height: options.resize?.maxHeight ?? 1024
    },
    show_labels: options.showLabels ?? false,
    show_borders: options.showBorders ?? false,
    fill_facets: options.fillFacets ?? true,
    log_level: options.logLevel ?? "warn",
    debug_flags: options.debugFlags ?? []
  };
}

export function normalizeProcessOutput(raw: unknown): import("./types.js").ProcessOutput {
  const output = snakeToCamelObject<import("./types.js").ProcessOutput>(raw);
  if (output.debug) {
    output.debug = {
      quantizedRgba: new Uint8Array(output.debug.quantizedRgba as unknown as number[]),
      facetMap: new Uint32Array(output.debug.facetMap as unknown as number[]),
      reductionRgba: output.debug.reductionRgba ? new Uint8Array(output.debug.reductionRgba as unknown as number[]) : undefined,
      borderPathRgba: output.debug.borderPathRgba ? new Uint8Array(output.debug.borderPathRgba as unknown as number[]) : undefined,
      borderSegmentationRgba: output.debug.borderSegmentationRgba ? new Uint8Array(output.debug.borderSegmentationRgba as unknown as number[]) : undefined,
      labelPlacementRgba: output.debug.labelPlacementRgba ? new Uint8Array(output.debug.labelPlacementRgba as unknown as number[]) : undefined
    };
  }
  return output;
}
